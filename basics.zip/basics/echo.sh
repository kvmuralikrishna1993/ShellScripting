#!/bin/bash
echo hello hussein, how are you
echo "Where do you live"
echo *
echo  "how * look like ?"