#!/bin/bash
echo "name is $name"
name="Hussein Alrubaye"
echo "name is $name"