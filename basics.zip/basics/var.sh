#!/bin/bash
name=hussein
echo "name:${name}like bana"
fullName="hussein Alrubaye"  
echo $fullName 
echo age: $age #  age has empty value
number=10
number=$(expr $number + 1)
echo "number: $number"